# NangProtector

Real-time security suite for Paper 1.21.x / Java 21 servers.
Author: **NangDev**

LuckPerms rank/permission protection, force-OP protection, command protection,
anti-bot, anti-grief, an adaptive low-overhead scanner, snapshot-based safe
recovery, and centralized Console/Telegram/Discord alerting.

## Why you have to build this yourself

This project was written in a sandboxed environment with **no internet access
and no Maven installed**, so it could not be compiled into a `.jar` there.
Building it is one command on any machine with internet access and Java 21 +
Maven installed - this is completely normal for Paper plugin development,
since `paper-api` and (if you want LuckPerms protection) `luckperms-api` are
always pulled from their own repositories, never bundled.

```bash
mvn -v          # confirm you have Maven + JDK 21
mvn package
```

The finished plugin will be at `target/NangProtector.jar`. Drop that into your
server's `plugins/` folder (LuckPerms is optional - if present, LuckPerms
protection activates automatically; if absent, every other protection module
still works normally).

## Before you trust it in production

I wrote every class here as real, complete, working code (no pseudocode, no
TODO stubs) based on the documented Bukkit/Paper and LuckPerms 5.x APIs. That
said, I could not compile or run it in this environment, so:

1. Run `mvn package` and fix any compiler errors first - most likely spot for
   drift is `LuckPermsProtection.java` / `SnapshotManager.java` if your
   server's LuckPerms version has renamed a method between API revisions.
2. Test on a non-production server first, especially the LuckPerms
   destructive-change detection and the force-OP auto-deop behavior.
3. Configure `config.yml` (Telegram bot token/chat ID, Discord webhook,
   protected groups/permissions) before enabling those integrations.

## Configuration

All tunables live in `config.yml` after first run (generated automatically):
protected LuckPerms groups/permissions, mass-change thresholds, snapshot
interval, scanner performance thresholds, anti-bot/anti-grief limits, and
Telegram/Discord settings.

## Console-only administration

```
/nangprotector status
/nangprotector lockdown <on|off>
/nangprotector snapshot <take|restore>
/nangprotector reload
/nangprotector threat [player|ip]
```

These only work when run from the server console - never from a player,
regardless of permissions, by design.
