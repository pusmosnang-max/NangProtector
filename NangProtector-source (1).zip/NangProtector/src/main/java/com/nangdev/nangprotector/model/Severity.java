package com.nangdev.nangprotector.model;

/**
 * Severity levels for security events, ordered from lowest to highest.
 */
public enum Severity {
    LOW(0),
    HIGH(1),
    CRITICAL(2);

    private final int rank;

    Severity(int rank) {
        this.rank = rank;
    }

    public boolean isAtLeast(Severity other) {
        return this.rank >= other.rank;
    }

    public static Severity fromString(String s, Severity fallback) {
        if (s == null) return fallback;
        try {
            return Severity.valueOf(s.trim().toUpperCase());
        } catch (IllegalArgumentException ex) {
            return fallback;
        }
    }
}
