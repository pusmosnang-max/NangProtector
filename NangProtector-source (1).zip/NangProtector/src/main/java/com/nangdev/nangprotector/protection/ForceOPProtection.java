package com.nangdev.nangprotector.protection;

import com.nangdev.nangprotector.alert.AlertManager;
import com.nangdev.nangprotector.config.ConfigManager;
import com.nangdev.nangprotector.model.Severity;
import com.nangdev.nangprotector.model.SecurityEvent;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Two layers of defense:
 *
 *  1. Reactive: no player may ever run /op or /deop themselves, no matter what
 *     permission they hold. Those commands are console-only. This closes the most
 *     common "ForceOP exploit" chain where a compromised admin session or a
 *     vulnerable plugin runs the op command as/through a player.
 *
 *  2. Detective (CRITICAL priority in the AdaptiveScanner): the set of operators
 *     is diffed on every scan against the last known set. Anything that appears
 *     which was not the direct result of a tracked console "op <name>" command is
 *     treated as an unauthorized escalation (e.g. a plugin exploit or a directly
 *     edited ops.json) and, if auto-deop is enabled, immediately reverted.
 */
public final class ForceOPProtection implements Listener {

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final AlertManager alerts;

    /** UUIDs whose current OP status is accounted for (either pre-existing at startup, or granted via a tracked console command). */
    private final Set<java.util.UUID> trackedOps = ConcurrentHashMap.newKeySet();

    public ForceOPProtection(JavaPlugin plugin, ConfigManager config, AlertManager alerts) {
        this.plugin = plugin;
        this.config = config;
        this.alerts = alerts;
        for (OfflinePlayer op : plugin.getServer().getOperators()) {
            trackedOps.add(op.getUniqueId());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        if (!config.forceOpProtectionEnabled()) return;
        String cmd = firstWord(event.getMessage());
        if (!isOpCommand(cmd)) return;

        event.setCancelled(true);
        Player player = event.getPlayer();
        player.sendMessage("\u00A7cThat command is console-only and has been blocked.");

        boolean wasOp = player.isOp();
        if (wasOp && config.forceOpAutoDeop()) {
            player.setOp(false);
            trackedOps.remove(player.getUniqueId());
        }

        alerts.raise(SecurityEvent.builder("FORCEOP", Severity.CRITICAL)
                .player(player.getName())
                .uuid(player.getUniqueId())
                .ip(player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : null)
                .world(player.getWorld().getName())
                .action("Player attempted to run '" + event.getMessage() + "' (blocked" + (wasOp ? ", OP_REMOVED" : "") + ")")
                .threatScore(50)
                .source("ForceOPProtection")
                .build());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onConsoleCommand(ServerCommandEvent event) {
        String cmd = firstWord(event.getCommand());
        if (!"op".equals(cmd)) return;
        String[] parts = event.getCommand().trim().split("\\s+");
        if (parts.length < 2) return;
        String targetName = parts[1];
        // give the server a tick to apply the op before we snapshot it as "trusted"
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            OfflinePlayer target = plugin.getServer().getOfflinePlayer(targetName);
            if (target.isOp()) trackedOps.add(target.getUniqueId());
        });
    }

    /**
     * Called by the AdaptiveScanner's CRITICAL pass. Cheap: only iterates the
     * (normally tiny) operator list, no disk or network I/O.
     */
    public void scanForUnauthorizedOps() {
        if (!config.forceOpProtectionEnabled()) return;
        for (OfflinePlayer op : plugin.getServer().getOperators()) {
            if (trackedOps.contains(op.getUniqueId())) continue;

            // newly discovered operator that we never tracked being granted via console
            trackedOps.add(op.getUniqueId()); // avoid re-alerting forever if auto-deop is off
            if (config.forceOpAutoDeop()) {
                op.setOp(false);
            }
            alerts.raise(SecurityEvent.builder("FORCEOP", Severity.CRITICAL)
                    .player(op.getName())
                    .uuid(op.getUniqueId())
                    .action("Unauthorized OP grant detected outside of tracked console commands"
                            + (config.forceOpAutoDeop() ? " (OP_REMOVED)" : " (auto-deop disabled, left as-is)"))
                    .threatScore(75)
                    .source("ForceOPProtection")
                    .build());
        }
    }

    private boolean isOpCommand(String cmd) {
        return "op".equals(cmd) || "deop".equals(cmd)
                || "minecraft:op".equals(cmd) || "minecraft:deop".equals(cmd);
    }

    private String firstWord(String raw) {
        String s = raw.trim();
        if (s.startsWith("/")) s = s.substring(1);
        int space = s.indexOf(' ');
        String word = space == -1 ? s : s.substring(0, space);
        return word.toLowerCase(Locale.ROOT);
    }
}
