package com.nangdev.nangprotector.antibot;

import com.nangdev.nangprotector.alert.AlertManager;
import com.nangdev.nangprotector.config.ConfigManager;
import com.nangdev.nangprotector.model.Severity;
import com.nangdev.nangprotector.model.SecurityEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerLoginEvent;

import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Event-driven (fires only on connection attempts, never a repeating scan).
 * Tracks connection attempts per IP in a sliding window; once the threshold is
 * exceeded the IP is temp-blocked for a configurable duration.
 */
public final class AntiBot implements Listener {

    private final ConfigManager config;
    private final AlertManager alerts;

    private final Map<String, Deque<Instant>> attempts = new ConcurrentHashMap<>();
    private final Map<String, Instant> blockedUntil = new ConcurrentHashMap<>();

    public AntiBot(ConfigManager config, AlertManager alerts) {
        this.config = config;
        this.alerts = alerts;
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onPreLogin(AsyncPlayerPreLoginEvent event) {
        if (!config.antiBotEnabled()) return;
        String ip = event.getAddress().getHostAddress();

        Instant blockUntil = blockedUntil.get(ip);
        if (blockUntil != null) {
            if (Instant.now().isBefore(blockUntil)) {
                event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, "\u00A7cToo many connection attempts. Try again later.");
                alerts.recordBlockedConnection();
                return;
            } else {
                blockedUntil.remove(ip);
            }
        }

        Deque<Instant> window = attempts.computeIfAbsent(ip, k -> new ArrayDeque<>());
        Instant now = Instant.now();
        synchronized (window) {
            window.addLast(now);
            Instant cutoff = now.minusSeconds(config.antiBotWindowSeconds());
            while (!window.isEmpty() && window.peekFirst().isBefore(cutoff)) window.pollFirst();

            if (window.size() > config.antiBotMaxConnPerWindow()) {
                blockedUntil.put(ip, now.plusSeconds(config.antiBotTempBlockSeconds()));
                event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, "\u00A7cToo many connection attempts. Try again later.");
                alerts.recordBlockedConnection();

                alerts.raise(SecurityEvent.builder("ANTI-BOT", Severity.HIGH)
                        .player(event.getName())
                        .uuid(event.getUniqueId())
                        .ip(ip)
                        .action("Connection rate limit exceeded (" + window.size() + " attempts in "
                                + config.antiBotWindowSeconds() + "s). Temp-blocked for " + config.antiBotTempBlockSeconds() + "s.")
                        .threatScore(15)
                        .source("AntiBot")
                        .build());
            }
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onLogin(PlayerLoginEvent event) {
        if (!config.antiBotEnabled()) return;
        String ip = event.getAddress().getHostAddress();
        Instant blockUntil = blockedUntil.get(ip);
        if (blockUntil != null && Instant.now().isBefore(blockUntil)) {
            event.disallow(PlayerLoginEvent.Result.KICK_OTHER, "\u00A7cToo many connection attempts. Try again later.");
            alerts.recordBlockedConnection();
        }
    }
}
