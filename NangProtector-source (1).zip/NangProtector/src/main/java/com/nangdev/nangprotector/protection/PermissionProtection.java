package com.nangdev.nangprotector.protection;

import com.nangdev.nangprotector.alert.AlertManager;
import com.nangdev.nangprotector.config.ConfigManager;
import com.nangdev.nangprotector.model.Severity;
import com.nangdev.nangprotector.model.SecurityEvent;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Fallback/defense-in-depth check that does not depend on LuckPerms being
 * installed: periodically verifies no online player unexpectedly holds a
 * "dangerous" permission (as configured) without being a known operator.
 * This is a HIGH-priority scanner check, not an every-tick check.
 */
public final class PermissionProtection {

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final AlertManager alerts;

    /** Players already alerted for their current dangerous-permission state, to avoid re-alerting every scan. */
    private final Set<java.util.UUID> alreadyFlagged = ConcurrentHashMap.newKeySet();

    public PermissionProtection(JavaPlugin plugin, ConfigManager config, AlertManager alerts) {
        this.plugin = plugin;
        this.config = config;
        this.alerts = alerts;
    }

    public void scan() {
        if (!config.permissionProtectionEnabled()) return;

        Set<java.util.UUID> stillFlagged = new HashSet<>();
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            if (player.isOp()) continue; // operators are expected to hold elevated permissions

            for (String perm : config.watchedDangerousPermissions()) {
                if (player.hasPermission(perm)) {
                    stillFlagged.add(player.getUniqueId());
                    if (!alreadyFlagged.contains(player.getUniqueId())) {
                        alerts.raise(SecurityEvent.builder("PERMISSION-PROTECTION", Severity.HIGH)
                                .player(player.getName())
                                .uuid(player.getUniqueId())
                                .world(player.getWorld().getName())
                                .action("Non-operator holds dangerous permission '" + perm + "'")
                                .threatScore(30)
                                .source("PermissionProtection")
                                .build());
                    }
                    break;
                }
            }
        }
        alreadyFlagged.retainAll(stillFlagged);
        alreadyFlagged.addAll(stillFlagged);
    }
}
