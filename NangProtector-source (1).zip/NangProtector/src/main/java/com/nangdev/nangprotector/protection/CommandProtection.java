package com.nangdev.nangprotector.protection;

import com.nangdev.nangprotector.alert.AlertManager;
import com.nangdev.nangprotector.config.ConfigManager;
import com.nangdev.nangprotector.model.Severity;
import com.nangdev.nangprotector.model.SecurityEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Enforces the configurable console-only command list. op/deop are intentionally
 * skipped here - ForceOPProtection owns those specifically because it also needs
 * to react to auto-deop and threat scoring for that particular exploit chain.
 */
public final class CommandProtection implements Listener {

    private final ConfigManager config;
    private final AlertManager alerts;

    public CommandProtection(ConfigManager config, AlertManager alerts) {
        this.config = config;
        this.alerts = alerts;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        if (!config.commandProtectionEnabled()) return;

        String cmd = firstWord(event.getMessage());
        if (cmd.equals("op") || cmd.equals("deop")) return; // handled by ForceOPProtection

        Set<String> consoleOnly = new HashSet<>();
        for (String s : config.consoleOnlyCommands()) consoleOnly.add(s.toLowerCase(Locale.ROOT));
        if (!consoleOnly.contains(cmd)) return;

        event.setCancelled(true);
        Player player = event.getPlayer();
        player.sendMessage("\u00A7cThat command is console-only and has been blocked.");

        alerts.raise(SecurityEvent.builder("COMMAND-PROTECTION", Severity.HIGH)
                .player(player.getName())
                .uuid(player.getUniqueId())
                .ip(player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : null)
                .world(player.getWorld().getName())
                .action("Blocked console-only command: '" + event.getMessage() + "'")
                .threatScore(20)
                .source("CommandProtection")
                .build());
    }

    private String firstWord(String raw) {
        String s = raw.trim();
        if (s.startsWith("/")) s = s.substring(1);
        int space = s.indexOf(' ');
        String word = space == -1 ? s : s.substring(0, space);
        return word.toLowerCase(Locale.ROOT);
    }
}
