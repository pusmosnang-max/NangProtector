package com.nangdev.nangprotector.util;

import org.bukkit.plugin.java.JavaPlugin;

/**
 * Purely cosmetic console banner printed on enable/disable - block-letter
 * "NANG" / "PROTECTOR" wordmark in a cyan-to-magenta gradient, in the spirit of
 * the classic big colorful plugin-startup banners.
 */
public final class Banner {

    private static final String RESET = "\u001B[0m";

    // 5-row block letters for N A N G
    private static final String[] NANG = {
        "██╗   ██╗ ██╗   █████╗   ██████╗ ",
        "███╗  ██║ ██║  ██╔══██╗ ██╔════╝ ",
        "██╔██╗██║ ██║  ███████║ ██║  ███╗",
        "██║╚████║ ██║  ██╔══██║ ██║   ██║",
        "██║ ╚███║ ██║  ██║  ██║ ╚██████╔╝",
        "╚═╝  ╚══╝ ╚═╝  ╚═╝  ╚═╝  ╚═════╝ "
    };

    private static final String[] PROTECTOR = {
        "██████╗ ██████╗   ██████╗ ████████╗███████╗ ██████╗████████╗ ██████╗ ██████╗ ",
        "██╔══██╗██╔══██╗ ██╔═══██╗╚══██╔══╝██╔════╝██╔════╝╚══██╔══╝██╔═══██╗██╔══██╗",
        "██████╔╝██████╔╝ ██║   ██║   ██║   █████╗  ██║        ██║   ██║   ██║██████╔╝",
        "██╔═══╝ ██╔══██╗ ██║   ██║   ██║   ██╔══╝  ██║        ██║   ██║   ██║██╔══██╗",
        "██║     ██║  ██║ ╚██████╔╝   ██║   ███████╗╚██████╗   ██║   ╚██████╔╝██║  ██║",
        "╚═╝     ╚═╝  ╚═╝  ╚═════╝    ╚═╝   ╚══════╝ ╚═════╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝"
    };

    private Banner() {}

    public static void print(JavaPlugin plugin, String version, String author, String status) {
        int[] gradient = {51, 45, 39, 33, 27, 21}; // cyan -> blue ANSI 256-color ramp
        StringBuilder sb = new StringBuilder("\n");
        for (int i = 0; i < NANG.length; i++) {
            sb.append(ansi(gradient[i % gradient.length])).append(NANG[i]).append(RESET).append('\n');
        }
        int[] gradient2 = {201, 165, 129, 93, 57, 21}; // magenta -> blue ANSI 256-color ramp
        for (int i = 0; i < PROTECTOR.length; i++) {
            sb.append(ansi(gradient2[i % gradient2.length])).append(PROTECTOR[i]).append(RESET).append('\n');
        }
        sb.append('\n');
        sb.append(ansi(51)).append("Version: ").append(RESET).append(version).append("   ");
        sb.append(ansi(51)).append("Author: ").append(RESET).append(author).append('\n');
        sb.append(ansi(51)).append("Status: ").append(RESET).append(status).append('\n');

        plugin.getServer().getConsoleSender().sendMessage(sb.toString());
    }

    private static String ansi(int code256) {
        return "\u001B[38;5;" + code256 + "m";
    }
}
