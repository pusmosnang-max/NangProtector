package com.nangdev.nangprotector.alert;

import com.nangdev.nangprotector.config.ConfigManager;
import com.nangdev.nangprotector.logging.SecurityLogger;
import com.nangdev.nangprotector.model.Severity;
import com.nangdev.nangprotector.model.SecurityEvent;
import com.nangdev.nangprotector.score.ThreatScoreManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Single centralized pipeline:
 *
 *   Security event -> Threat classification -> Security log -> AlertManager
 *                                                                  |-- Console (always, subject to min level)
 *                                                                  |-- Telegram (subject to min level + aggregation)
 *                                                                  |-- Discord  (subject to min level + aggregation)
 *
 * There is intentionally only ONE detection->alert pipeline; individual protection
 * modules never talk to Telegram/Discord/the log directly. This avoids duplicate
 * processing and keeps resource usage predictable.
 *
 * Non-CRITICAL, high-frequency event types are aggregated: instead of spamming
 * Telegram/Discord with one message per hit, counts are accumulated for
 * `alerts.aggregation-window-seconds` and flushed as a single summary if the
 * total crosses `alerts.aggregation-trigger-count`. CRITICAL events always fire
 * immediately - they are never held back for aggregation.
 */
public final class AlertManager {

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final SecurityLogger logger;
    private final ThreatScoreManager threatScore;
    private final ConsoleAlert consoleAlert;
    private final TelegramAlert telegramAlert;
    private final DiscordAlert discordAlert;

    private final Map<String, AtomicInteger> windowCounts = new ConcurrentHashMap<>();
    private final AtomicInteger windowBlocked = new AtomicInteger(0);
    private final AtomicInteger windowTotal = new AtomicInteger(0);
    private BukkitTask flushTask;

    public AlertManager(JavaPlugin plugin, ConfigManager config, SecurityLogger logger, ThreatScoreManager threatScore) {
        this.plugin = plugin;
        this.config = config;
        this.logger = logger;
        this.threatScore = threatScore;
        this.consoleAlert = new ConsoleAlert(plugin, config);
        this.telegramAlert = new TelegramAlert(plugin, config);
        this.discordAlert = new DiscordAlert(plugin, config);
        scheduleFlush();
    }

    private void scheduleFlush() {
        long ticks = Math.max(20L, config.aggregationWindowSeconds() * 20L);
        this.flushTask = plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, this::flushAggregation, ticks, ticks);
    }

    /** Main entry point used by every protection module. */
    public void raise(SecurityEvent event) {
        if (event.getThreatScore() != 0) {
            threatScore.add(event.getUuid() != null ? event.getUuid().toString() : event.getIp(), event.getThreatScore());
        }

        logger.log(event);
        consoleAlert.send(event);

        if (event.getSeverity() == Severity.CRITICAL) {
            telegramAlert.send(event);
            discordAlert.send(event);
        } else {
            windowCounts.computeIfAbsent(event.getType(), k -> new AtomicInteger()).incrementAndGet();
            windowTotal.incrementAndGet();
            // still send an individual alert unless the window is currently "loud"
            if (windowTotal.get() < config.aggregationTriggerCount()) {
                telegramAlert.send(event);
                discordAlert.send(event);
            }
        }
    }

    public void recordBlockedConnection() {
        windowBlocked.incrementAndGet();
    }

    private void flushAggregation() {
        int total = windowTotal.getAndSet(0);
        int blocked = windowBlocked.getAndSet(0);
        Map<String, AtomicInteger> snapshot = new ConcurrentHashMap<>(windowCounts);
        windowCounts.clear();

        if (total < config.aggregationTriggerCount()) return;

        StringBuilder body = new StringBuilder();
        body.append(total).append(" suspicious events detected\n");
        if (blocked > 0) body.append(blocked).append(" connections blocked\n");
        for (Map.Entry<String, AtomicInteger> entry : snapshot.entrySet()) {
            body.append(entry.getKey()).append(": ").append(entry.getValue().get()).append('\n');
        }
        body.append("\nProtection Status: \uD83D\uDFE2 ACTIVE");

        consoleAlert.sendRaw("Attack summary - " + total + " events in the last " + config.aggregationWindowSeconds() + "s");
        telegramAlert.sendText("\uD83D\uDEA8 <b>NangProtector Attack Summary</b>\n\n" + body);
        discordAlert.sendPlainSummary("\uD83D\uDEA8 NangProtector Attack Summary", body.toString());
    }

    public void shutdown() {
        if (flushTask != null) flushTask.cancel();
    }
}
