package com.nangdev.nangprotector.score;

import com.nangdev.nangprotector.config.ConfigManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Tracks a decaying threat score per source (UUID or IP string key) plus a global
 * server-wide score. Decays once a minute so old, resolved incidents stop counting
 * against a player forever.
 */
public final class ThreatScoreManager {

    private final ConfigManager config;
    private final Map<String, AtomicInteger> perSource = new ConcurrentHashMap<>();
    private final AtomicInteger global = new AtomicInteger(0);
    private BukkitTask decayTask;

    public ThreatScoreManager(JavaPlugin plugin, ConfigManager config) {
        this.config = config;
        this.decayTask = plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, this::decay, 20L * 60, 20L * 60);
    }

    public int add(String sourceKey, int amount) {
        global.addAndGet(amount);
        if (sourceKey == null) return global.get();
        return perSource.computeIfAbsent(sourceKey, k -> new AtomicInteger(0)).addAndGet(amount);
    }

    public int add(UUID uuid, int amount) {
        return add(uuid == null ? null : uuid.toString(), amount);
    }

    public int get(String sourceKey) {
        AtomicInteger v = perSource.get(sourceKey);
        return v == null ? 0 : v.get();
    }

    public int globalScore() {
        return global.get();
    }

    public boolean isOverLockdownThreshold() {
        return global.get() >= config.lockdownThreshold();
    }

    private void decay() {
        int amount = config.threatDecayPerMinute();
        if (amount <= 0) return;
        global.updateAndGet(v -> Math.max(0, v - amount));
        for (AtomicInteger v : perSource.values()) {
            v.updateAndGet(cur -> Math.max(0, cur - amount));
        }
    }

    public void resetGlobal() {
        global.set(0);
    }

    public void shutdown() {
        if (decayTask != null) decayTask.cancel();
    }
}
