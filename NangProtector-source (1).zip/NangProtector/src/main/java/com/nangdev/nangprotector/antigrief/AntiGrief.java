package com.nangdev.nangprotector.antigrief;

import com.nangdev.nangprotector.alert.AlertManager;
import com.nangdev.nangprotector.config.ConfigManager;
import com.nangdev.nangprotector.model.Severity;
import com.nangdev.nangprotector.model.SecurityEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Simple, cheap per-player counters reset once per second - no world scanning,
 * no chunk iteration. Purely reactive to the block events Bukkit already fires.
 */
public final class AntiGrief implements Listener {

    private final ConfigManager config;
    private final AlertManager alerts;

    private static final class Counter {
        final AtomicInteger count = new AtomicInteger();
        final AtomicLong windowStartSecond = new AtomicLong(currentSecond());
    }

    private final Map<java.util.UUID, Counter> breakCounters = new ConcurrentHashMap<>();
    private final Map<java.util.UUID, Counter> placeCounters = new ConcurrentHashMap<>();

    public AntiGrief(ConfigManager config, AlertManager alerts) {
        this.config = config;
        this.alerts = alerts;
    }

    private static long currentSecond() {
        return System.currentTimeMillis() / 1000L;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (!config.antiGriefEnabled()) return;
        check(event.getPlayer(), breakCounters, config.maxBlocksBrokenPerSecond(), "block-break");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (!config.antiGriefEnabled()) return;
        check(event.getPlayer(), placeCounters, config.maxBlocksPlacedPerSecond(), "block-place");
    }

    private void check(Player player, Map<java.util.UUID, Counter> counters, int limit, String kind) {
        if (player.hasPermission("nangprotector.bypass")) return;

        Counter counter = counters.computeIfAbsent(player.getUniqueId(), k -> new Counter());
        long now = currentSecond();
        if (counter.windowStartSecond.getAndSet(now) != now) {
            counter.count.set(0);
        }
        int current = counter.count.incrementAndGet();
        if (current == limit + 1) { // alert once per burst, not once per subsequent block
            alerts.raise(SecurityEvent.builder("ANTI-GRIEF", Severity.HIGH)
                    .player(player.getName())
                    .uuid(player.getUniqueId())
                    .world(player.getWorld().getName())
                    .action("Abnormal " + kind + " rate: " + current + "/s (limit " + limit + ")")
                    .threatScore(10)
                    .source("AntiGrief")
                    .build());
        }
    }
}
