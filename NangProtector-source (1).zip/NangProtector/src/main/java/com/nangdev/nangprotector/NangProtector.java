package com.nangdev.nangprotector;

import com.nangdev.nangprotector.alert.AlertManager;
import com.nangdev.nangprotector.antibot.AntiBot;
import com.nangdev.nangprotector.antigrief.AntiGrief;
import com.nangdev.nangprotector.commands.NangProtectorCommand;
import com.nangdev.nangprotector.config.ConfigManager;
import com.nangdev.nangprotector.lockdown.LockdownManager;
import com.nangdev.nangprotector.logging.SecurityLogger;
import com.nangdev.nangprotector.protection.CommandProtection;
import com.nangdev.nangprotector.protection.ForceOPProtection;
import com.nangdev.nangprotector.protection.LuckPermsProtection;
import com.nangdev.nangprotector.protection.PermissionProtection;
import com.nangdev.nangprotector.scanner.AdaptiveScanner;
import com.nangdev.nangprotector.score.ThreatScoreManager;
import com.nangdev.nangprotector.snapshot.SnapshotManager;
import com.nangdev.nangprotector.util.Banner;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * NangProtector
 * Author: NangDev
 *
 * Real-time server security suite: LuckPerms rank/permission protection,
 * force-OP protection, command protection, anti-bot, anti-grief, an adaptive
 * low-overhead scanner, and centralized Console/Telegram/Discord alerting.
 *
 * Every module is independent and fail-safe: LuckPerms, Telegram, and Discord
 * are all optional, and their absence or downtime never disables the rest of
 * the plugin's protections.
 */
public final class NangProtector extends JavaPlugin {

    private ConfigManager configManager;
    private SecurityLogger securityLogger;
    private ThreatScoreManager threatScoreManager;
    private AlertManager alertManager;

    private ForceOPProtection forceOPProtection;
    private CommandProtection commandProtection;
    private PermissionProtection permissionProtection;
    private LuckPermsProtection luckPermsProtection;
    private AntiBot antiBot;
    private AntiGrief antiGrief;
    private AdaptiveScanner adaptiveScanner;
    private SnapshotManager snapshotManager;
    private LockdownManager lockdownManager;

    private LuckPerms luckPerms; // null if LuckPerms is not installed

    @Override
    public void onEnable() {
        Banner.print(this, getDescription().getVersion(), "NangDev", "STARTING...");

        try {
            this.configManager = new ConfigManager(this);
            this.securityLogger = new SecurityLogger(this, configManager);
            this.threatScoreManager = new ThreatScoreManager(this, configManager);
            this.alertManager = new AlertManager(this, configManager, securityLogger, threatScoreManager);

            this.lockdownManager = new LockdownManager(configManager);
            getServer().getPluginManager().registerEvents(lockdownManager, this);

            this.forceOPProtection = new ForceOPProtection(this, configManager, alertManager);
            getServer().getPluginManager().registerEvents(forceOPProtection, this);

            this.commandProtection = new CommandProtection(configManager, alertManager);
            getServer().getPluginManager().registerEvents(commandProtection, this);

            this.permissionProtection = new PermissionProtection(this, configManager, alertManager);

            this.antiBot = new AntiBot(configManager, alertManager);
            getServer().getPluginManager().registerEvents(antiBot, this);

            this.antiGrief = new AntiGrief(configManager, alertManager);
            getServer().getPluginManager().registerEvents(antiGrief, this);

            this.snapshotManager = new SnapshotManager(this, configManager, () -> luckPerms);

            hookLuckPerms();
            snapshotManager.start();

            this.adaptiveScanner = new AdaptiveScanner(this, configManager, alertManager,
                    forceOPProtection, permissionProtection, threatScoreManager, lockdownManager);
            adaptiveScanner.start();

            NangProtectorCommand commandExecutor = new NangProtectorCommand(
                    this, configManager, lockdownManager, snapshotManager, threatScoreManager);
            getCommand("nangprotector").setExecutor(commandExecutor);

            Banner.print(this, getDescription().getVersion(), "NangDev", "ACTIVE \u2705");
        } catch (Exception e) {
            getLogger().severe("[NangProtector] Failed to enable safely - disabling to avoid running in a broken state.");
            getLogger().severe(e.toString());
            getServer().getPluginManager().disablePlugin(this);
        }
    }

    private void hookLuckPerms() {
        if (getServer().getPluginManager().getPlugin("LuckPerms") == null) {
            getLogger().info("[NangProtector] LuckPerms not found - LuckPerms-specific protections are disabled. All other protections remain active.");
            return;
        }
        try {
            this.luckPerms = LuckPermsProvider.get();
        } catch (IllegalStateException notReady) {
            getLogger().warning("[NangProtector] LuckPerms is installed but not yet ready during startup. LuckPerms protection will not be active this session.");
            return;
        }

        this.luckPermsProtection = new LuckPermsProtection(this, configManager, alertManager, snapshotManager);
        boolean hooked = luckPermsProtection.hook();
        if (hooked) {
            getLogger().info("[NangProtector] LuckPerms detected - LuckPerms rank/permission protection is ACTIVE.");
        }
    }

    @Override
    public void onDisable() {
        if (adaptiveScanner != null) adaptiveScanner.stop();
        if (snapshotManager != null) snapshotManager.stop();
        if (luckPermsProtection != null) luckPermsProtection.unhook();
        if (threatScoreManager != null) threatScoreManager.shutdown();
        if (alertManager != null) alertManager.shutdown();
        if (securityLogger != null) securityLogger.shutdown();
        if (configManager != null) {
            Banner.print(this, getDescription().getVersion(), "NangDev", "STOPPED");
        }
    }
}
