package com.nangdev.nangprotector.config;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

/**
 * Thin, typed wrapper around config.yml. Re-reading is cheap; reload() swaps the
 * underlying FileConfiguration reference so live modules always see fresh values
 * on their next read without needing to be re-constructed.
 */
public final class ConfigManager {

    private final JavaPlugin plugin;
    private FileConfiguration cfg;

    public ConfigManager(JavaPlugin plugin) {
        this.plugin = plugin;
        plugin.saveDefaultConfig();
        this.cfg = plugin.getConfig();
    }

    public void reload() {
        plugin.reloadConfig();
        this.cfg = plugin.getConfig();
    }

    private FileConfiguration c() { return cfg; }

    // ---- LuckPerms protection ----
    public boolean luckPermsProtectionEnabled() { return c().getBoolean("luckperms-protection.enabled", true); }
    public List<String> protectedGroups() { return c().getStringList("luckperms-protection.protected-groups"); }
    public List<String> protectedUsers() { return c().getStringList("luckperms-protection.protected-users"); }
    public List<String> protectedPermissions() { return c().getStringList("luckperms-protection.protected-permissions"); }

    public boolean massChangeEnabled() { return c().getBoolean("luckperms-protection.mass-change.enabled", true); }
    public int massChangeThreshold() { return c().getInt("luckperms-protection.mass-change.changes-per-window", 20); }
    public int massChangeWindowSeconds() { return c().getInt("luckperms-protection.mass-change.window-seconds", 5); }

    public boolean snapshotsEnabled() { return c().getBoolean("luckperms-protection.snapshots.enabled", true); }
    public int snapshotIntervalMinutes() { return c().getInt("luckperms-protection.snapshots.interval-minutes", 10); }
    public int maxSnapshots() { return c().getInt("luckperms-protection.snapshots.max-snapshots", 10); }

    // ---- ForceOP / permission / command protection ----
    public boolean forceOpProtectionEnabled() { return c().getBoolean("forceop-protection.enabled", true); }
    public boolean forceOpAutoDeop() { return c().getBoolean("forceop-protection.auto-deop", true); }

    public boolean permissionProtectionEnabled() { return c().getBoolean("permission-protection.enabled", true); }
    public List<String> watchedDangerousPermissions() { return c().getStringList("permission-protection.watch-dangerous-permissions"); }

    public boolean commandProtectionEnabled() { return c().getBoolean("command-protection.enabled", true); }
    public List<String> consoleOnlyCommands() { return c().getStringList("command-protection.console-only-commands"); }

    // ---- Scanner ----
    public boolean scannerEnabled() { return c().getBoolean("scanner.enabled", true); }
    public long scannerTargetIntervalMs() { return c().getLong("scanner.target-interval-ms", 1000); }
    public long scannerMinIntervalMs() { return c().getLong("scanner.minimum-interval-ms", 1000); }
    public long scannerMaxIntervalMs() { return c().getLong("scanner.maximum-interval-ms", 10000); }
    public boolean scannerAdaptive() { return c().getBoolean("scanner.adaptive", true); }
    public double msptWarningThreshold() { return c().getDouble("scanner.mspt-warning-threshold", 45.0); }
    public double msptCriticalThreshold() { return c().getDouble("scanner.mspt-critical-threshold", 65.0); }

    // ---- Anti-bot ----
    public boolean antiBotEnabled() { return c().getBoolean("anti-bot.enabled", true); }
    public int antiBotMaxConnPerWindow() { return c().getInt("anti-bot.max-connections-per-ip-per-window", 5); }
    public int antiBotWindowSeconds() { return c().getInt("anti-bot.window-seconds", 10); }
    public int antiBotTempBlockSeconds() { return c().getInt("anti-bot.temp-block-seconds", 300); }

    // ---- Anti-grief ----
    public boolean antiGriefEnabled() { return c().getBoolean("anti-grief.enabled", true); }
    public int maxBlocksBrokenPerSecond() { return c().getInt("anti-grief.max-blocks-broken-per-second", 40); }
    public int maxBlocksPlacedPerSecond() { return c().getInt("anti-grief.max-blocks-placed-per-second", 40); }

    // ---- Threat score ----
    public int threatDecayPerMinute() { return c().getInt("threat-score.decay-per-minute", 5); }
    public int lockdownThreshold() { return c().getInt("threat-score.lockdown-threshold", 100); }

    // ---- Logging ----
    public String logFile() { return c().getString("logging.file", "logs/security.log"); }
    public int logMaxSizeMb() { return c().getInt("logging.max-size-mb", 10); }
    public boolean logIncludeIp() { return c().getBoolean("logging.include-ip", true); }

    // ---- Alerts ----
    public String minimumConsoleLevel() { return c().getString("alerts.minimum-console-level", "LOW"); }
    public int aggregationWindowSeconds() { return c().getInt("alerts.aggregation-window-seconds", 15); }
    public int aggregationTriggerCount() { return c().getInt("alerts.aggregation-trigger-count", 10); }

    // ---- Telegram ----
    public boolean telegramEnabled() { return c().getBoolean("telegram.enabled", false); }
    public String telegramBotToken() { return c().getString("telegram.bot-token", ""); }
    public String telegramChatId() { return c().getString("telegram.chat-id", ""); }
    public String telegramMinLevel() { return c().getString("telegram.minimum-alert-level", "HIGH"); }
    public int telegramCooldownSeconds() { return c().getInt("telegram.alert-cooldown-seconds", 10); }
    public int telegramMaxPerMinute() { return c().getInt("telegram.max-messages-per-minute", 20); }

    // ---- Discord ----
    public boolean discordEnabled() { return c().getBoolean("discord.enabled", false); }
    public String discordWebhookUrl() { return c().getString("discord.webhook-url", ""); }
    public String discordMinLevel() { return c().getString("discord.minimum-alert-level", "HIGH"); }
    public int discordCooldownSeconds() { return c().getInt("discord.alert-cooldown-seconds", 10); }
    public int discordMaxPerMinute() { return c().getInt("discord.max-messages-per-minute", 20); }
    public String discordServerName() { return c().getString("discord.server-name", "SERVER"); }

    // ---- Lockdown ----
    public boolean autoLockdownOnCriticalThreat() { return c().getBoolean("lockdown.auto-lockdown-on-critical-threat", false); }
    public String lockdownKickMessage() { return c().getString("lockdown.kick-message", "&cServer is locked down."); }
}
