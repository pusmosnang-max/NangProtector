package com.nangdev.nangprotector.scanner;

import com.nangdev.nangprotector.alert.AlertManager;
import com.nangdev.nangprotector.config.ConfigManager;
import com.nangdev.nangprotector.lockdown.LockdownManager;
import com.nangdev.nangprotector.model.Severity;
import com.nangdev.nangprotector.model.SecurityEvent;
import com.nangdev.nangprotector.protection.ForceOPProtection;
import com.nangdev.nangprotector.protection.PermissionProtection;
import com.nangdev.nangprotector.score.ThreatScoreManager;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * This is a *safety/verification* layer, not the primary detection mechanism -
 * most detection here is event-driven (LuckPerms events, command events, block
 * events). The scanner exists to catch anything that slips between events (e.g.
 * ops.json edited directly on disk) with minimal, adaptive overhead.
 *
 * Self-reschedules on the main thread with a delay that grows as TPS drops:
 * healthy server -> ~1s cadence running everything; degraded server -> longer
 * cadence, CRITICAL checks only; heavy load -> longest cadence, CRITICAL only,
 * and even those checks are kept O(online players) at worst - never O(world).
 */
public final class AdaptiveScanner {

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final AlertManager alerts;
    private final ForceOPProtection forceOp;
    private final PermissionProtection permissionProtection;
    private final ThreatScoreManager threatScore;
    private final LockdownManager lockdown;

    private volatile boolean running = false;
    private int cycleCounter = 0;
    private boolean lastCycleWasCritical = false;

    public AdaptiveScanner(JavaPlugin plugin, ConfigManager config, AlertManager alerts,
                            ForceOPProtection forceOp, PermissionProtection permissionProtection,
                            ThreatScoreManager threatScore, LockdownManager lockdown) {
        this.plugin = plugin;
        this.config = config;
        this.alerts = alerts;
        this.forceOp = forceOp;
        this.permissionProtection = permissionProtection;
        this.threatScore = threatScore;
        this.lockdown = lockdown;
    }

    public void start() {
        if (!config.scannerEnabled()) return;
        running = true;
        plugin.getServer().getScheduler().runTaskLater(plugin, this::tick, 20L * 10);
    }

    public void stop() {
        running = false;
    }

    private void tick() {
        if (!running) return;
        long startNanos = System.nanoTime();

        double tps = estimateTps();
        double estimatedMspt = tps > 0 ? 1000.0 / tps : 0;
        boolean healthy = estimatedMspt <= config.msptWarningThreshold();
        boolean heavyLoad = estimatedMspt >= config.msptCriticalThreshold();

        // CRITICAL priority checks - always run, kept cheap (bounded by operator/online-player counts)
        forceOp.scanForUnauthorizedOps();
        if (config.autoLockdownOnCriticalThreat() && threatScore.isOverLockdownThreshold() && !lockdown.isActive()) {
            lockdown.enable();
            alerts.raise(SecurityEvent.builder("LOCKDOWN", Severity.CRITICAL)
                    .action("Automatic lockdown engaged: global threat score " + threatScore.globalScore()
                            + " exceeded threshold " + config.lockdownThreshold())
                    .threatScore(0)
                    .source("AdaptiveScanner")
                    .build());
        }

        if (!heavyLoad) {
            // HIGH priority checks
            permissionProtection.scan();
        }

        if (healthy) {
            // LOW priority / extended checks, only every 10th healthy cycle to stay cheap
            cycleCounter++;
            if (cycleCounter % 10 == 0) {
                // room for extended statistics / historical analysis; intentionally minimal by default
            }
        }

        lastCycleWasCritical = heavyLoad;

        long elapsedMs = (System.nanoTime() - startNanos) / 1_000_000L;
        long delay = computeNextDelayTicks(estimatedMspt, elapsedMs);

        if (running) {
            plugin.getServer().getScheduler().runTaskLater(plugin, this::tick, delay);
        }
    }

    private long computeNextDelayTicks(double estimatedMspt, long elapsedMs) {
        long targetMs = config.scannerTargetIntervalMs();
        if (!config.scannerAdaptive()) {
            return Math.max(1L, targetMs / 50L); // ms -> ticks (20 ticks/sec)
        }

        long minMs = config.scannerMinIntervalMs();
        long maxMs = config.scannerMaxIntervalMs();

        long resultMs;
        if (estimatedMspt <= config.msptWarningThreshold()) {
            resultMs = minMs;
        } else if (estimatedMspt >= config.msptCriticalThreshold()) {
            resultMs = maxMs;
        } else {
            // linear interpolation between warning and critical thresholds
            double span = config.msptCriticalThreshold() - config.msptWarningThreshold();
            double frac = span <= 0 ? 1.0 : (estimatedMspt - config.msptWarningThreshold()) / span;
            resultMs = minMs + (long) ((maxMs - minMs) * Math.max(0, Math.min(1, frac)));
        }

        // never spend more than max-ms-per-scan worth of budget too often: if a cycle
        // ran long, back off a little further next time to protect TPS.
        if (elapsedMs > config.scannerMaxIntervalMs()) {
            resultMs = maxMs;
        }

        long ticks = resultMs / 50L; // 50ms per tick
        return Math.max(1L, ticks);
    }

    private double estimateTps() {
        try {
            double[] tps = plugin.getServer().getTPS();
            if (tps != null && tps.length > 0) {
                return Math.min(20.0, tps[0]);
            }
        } catch (Throwable ignored) {
            // getTPS() is a Paper API addition; fall back to "healthy" if unavailable
        }
        return 20.0;
    }
}
