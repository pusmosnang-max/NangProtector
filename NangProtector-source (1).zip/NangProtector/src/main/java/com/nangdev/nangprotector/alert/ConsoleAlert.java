package com.nangdev.nangprotector.alert;

import com.nangdev.nangprotector.config.ConfigManager;
import com.nangdev.nangprotector.model.Severity;
import com.nangdev.nangprotector.model.SecurityEvent;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

public final class ConsoleAlert {

    private final JavaPlugin plugin;
    private final ConfigManager config;

    public ConsoleAlert(JavaPlugin plugin, ConfigManager config) {
        this.plugin = plugin;
        this.config = config;
    }

    public void send(SecurityEvent e) {
        Severity min = Severity.fromString(config.minimumConsoleLevel(), Severity.LOW);
        if (!e.getSeverity().isAtLeast(min)) return;

        ChatColor color = switch (e.getSeverity()) {
            case CRITICAL -> ChatColor.RED;
            case HIGH -> ChatColor.GOLD;
            case LOW -> ChatColor.YELLOW;
        };

        StringBuilder sb = new StringBuilder();
        sb.append(ChatColor.AQUA).append("[NangProtector] ")
          .append(color).append('[').append(e.getSeverity()).append("] ")
          .append(e.getType()).append(ChatColor.RESET);
        sb.append(" - ").append(e.getAction());
        if (e.getPlayer() != null) sb.append(" | Player=").append(e.getPlayer());
        if (e.getIp() != null && config.logIncludeIp()) sb.append(" | IP=").append(e.getIp());
        sb.append(" | ThreatScore=").append(e.getThreatScore());
        sb.append(" | Source=").append(e.getDetectionSource());

        plugin.getServer().getConsoleSender().sendMessage(sb.toString());
    }

    public void sendRaw(String message) {
        plugin.getServer().getConsoleSender().sendMessage(ChatColor.AQUA + "[NangProtector] " + ChatColor.RESET + message);
    }
}
