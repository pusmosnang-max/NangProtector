package com.nangdev.nangprotector.commands;

import com.nangdev.nangprotector.config.ConfigManager;
import com.nangdev.nangprotector.lockdown.LockdownManager;
import com.nangdev.nangprotector.score.ThreatScoreManager;
import com.nangdev.nangprotector.snapshot.SnapshotManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * DDoSGuard/NangProtector administrative commands are CONSOLE-ONLY regardless of
 * any permission a player might hold - this is enforced here unconditionally,
 * not via a permission node, so it can never be bypassed by a permission
 * misconfiguration or a compromised LuckPerms grant.
 */
public final class NangProtectorCommand implements CommandExecutor {

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final LockdownManager lockdown;
    private final SnapshotManager snapshots;
    private final ThreatScoreManager threatScore;

    public NangProtectorCommand(JavaPlugin plugin, ConfigManager config, LockdownManager lockdown,
                                 SnapshotManager snapshots, ThreatScoreManager threatScore) {
        this.plugin = plugin;
        this.config = config;
        this.lockdown = lockdown;
        this.snapshots = snapshots;
        this.threatScore = threatScore;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof ConsoleCommandSender)) {
            sender.sendMessage("\u00A7cThis command is console-only.");
            return true;
        }

        if (args.length == 0) {
            sendUsage(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "status" -> {
                sender.sendMessage("\u00A7b[NangProtector] \u00A7fLockdown: " + (lockdown.isActive() ? "\u00A7cACTIVE" : "\u00A7ainactive"));
                sender.sendMessage("\u00A7b[NangProtector] \u00A7fGlobal threat score: \u00A7e" + threatScore.globalScore());
            }
            case "lockdown" -> {
                if (args.length < 2) {
                    sender.sendMessage("Usage: /nangprotector lockdown <on|off>");
                    return true;
                }
                if (args[1].equalsIgnoreCase("on")) {
                    lockdown.enable();
                    sender.sendMessage("\u00A7c[NangProtector] Lockdown ENABLED.");
                } else if (args[1].equalsIgnoreCase("off")) {
                    lockdown.disable();
                    sender.sendMessage("\u00A7a[NangProtector] Lockdown disabled.");
                } else {
                    sender.sendMessage("Usage: /nangprotector lockdown <on|off>");
                }
            }
            case "snapshot" -> {
                if (args.length < 2) {
                    sender.sendMessage("Usage: /nangprotector snapshot <take|restore>");
                    return true;
                }
                if (args[1].equalsIgnoreCase("take")) {
                    plugin.getServer().getScheduler().runTaskAsynchronously(plugin, snapshots::takeSnapshot);
                    sender.sendMessage("\u00A7a[NangProtector] Snapshot queued.");
                } else if (args[1].equalsIgnoreCase("restore")) {
                    plugin.getServer().getScheduler().runTaskAsynchronously(plugin,
                            () -> snapshots.restoreLatestValidSnapshot("manual console request"));
                    sender.sendMessage("\u00A7a[NangProtector] Restore from latest valid snapshot queued (see console/log for result).");
                } else {
                    sender.sendMessage("Usage: /nangprotector snapshot <take|restore>");
                }
            }
            case "reload" -> {
                config.reload();
                sender.sendMessage("\u00A7a[NangProtector] Configuration reloaded.");
            }
            case "threat" -> {
                if (args.length < 2) {
                    sender.sendMessage("\u00A7b[NangProtector] \u00A7fGlobal threat score: \u00A7e" + threatScore.globalScore());
                } else {
                    sender.sendMessage("\u00A7b[NangProtector] \u00A7fThreat score for '" + args[1] + "': \u00A7e" + threatScore.get(args[1]));
                }
            }
            default -> sendUsage(sender);
        }
        return true;
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage("\u00A7bNangProtector \u00A77- console-only administrative command");
        sender.sendMessage("\u00A77/nangprotector status");
        sender.sendMessage("\u00A77/nangprotector lockdown <on|off>");
        sender.sendMessage("\u00A77/nangprotector snapshot <take|restore>");
        sender.sendMessage("\u00A77/nangprotector reload");
        sender.sendMessage("\u00A77/nangprotector threat [player|ip]");
    }
}
