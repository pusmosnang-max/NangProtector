package com.nangdev.nangprotector.model;

import java.time.Instant;
import java.util.UUID;

/**
 * A single detected security event, flowing: detector -> ThreatScore -> SecurityLogger -> AlertManager.
 */
public final class SecurityEvent {

    private final Instant timestamp = Instant.now();
    private final String type;              // e.g. "LUCKPERMS", "FORCEOP", "ANTI-BOT"
    private final Severity severity;
    private final String player;            // nullable
    private final UUID uuid;                // nullable
    private final String ip;                // nullable
    private final String world;             // nullable
    private final String action;            // human-readable description
    private final int threatScore;
    private final String detectionSource;   // module name

    public SecurityEvent(String type, Severity severity, String player, UUID uuid, String ip,
                          String world, String action, int threatScore, String detectionSource) {
        this.type = type;
        this.severity = severity;
        this.player = player;
        this.uuid = uuid;
        this.ip = ip;
        this.world = world;
        this.action = action;
        this.threatScore = threatScore;
        this.detectionSource = detectionSource;
    }

    public Instant getTimestamp() { return timestamp; }
    public String getType() { return type; }
    public Severity getSeverity() { return severity; }
    public String getPlayer() { return player; }
    public UUID getUuid() { return uuid; }
    public String getIp() { return ip; }
    public String getWorld() { return world; }
    public String getAction() { return action; }
    public int getThreatScore() { return threatScore; }
    public String getDetectionSource() { return detectionSource; }

    public static Builder builder(String type, Severity severity) {
        return new Builder(type, severity);
    }

    public static final class Builder {
        private final String type;
        private final Severity severity;
        private String player;
        private UUID uuid;
        private String ip;
        private String world;
        private String action = "";
        private int threatScore = 0;
        private String detectionSource = "UNKNOWN";

        private Builder(String type, Severity severity) {
            this.type = type;
            this.severity = severity;
        }

        public Builder player(String player) { this.player = player; return this; }
        public Builder uuid(UUID uuid) { this.uuid = uuid; return this; }
        public Builder ip(String ip) { this.ip = ip; return this; }
        public Builder world(String world) { this.world = world; return this; }
        public Builder action(String action) { this.action = action; return this; }
        public Builder threatScore(int threatScore) { this.threatScore = threatScore; return this; }
        public Builder source(String source) { this.detectionSource = source; return this; }

        public SecurityEvent build() {
            return new SecurityEvent(type, severity, player, uuid, ip, world, action, threatScore, detectionSource);
        }
    }
}
