package com.nangdev.nangprotector.alert;

import com.nangdev.nangprotector.config.ConfigManager;
import com.nangdev.nangprotector.model.Severity;
import com.nangdev.nangprotector.model.SecurityEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Notification-only. Never executes anything the bot API might send back;
 * responses are read purely for logging/diagnostics.
 */
public final class TelegramAlert {

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();

    private final AtomicLong lastSentMillis = new AtomicLong(0);
    private final Deque<Instant> sentTimestamps = new ArrayDeque<>();

    public TelegramAlert(JavaPlugin plugin, ConfigManager config) {
        this.plugin = plugin;
        this.config = config;
    }

    public void send(SecurityEvent e) {
        if (!config.telegramEnabled()) return;
        Severity min = Severity.fromString(config.telegramMinLevel(), Severity.HIGH);
        if (!e.getSeverity().isAtLeast(min)) return;
        sendText(formatMessage(e));
    }

    public void sendText(String text) {
        if (!config.telegramEnabled()) return;
        if (!allowedByRateLimit()) return;

        String token = config.telegramBotToken();
        String chatId = config.telegramChatId();
        if (token == null || token.isBlank() || token.startsWith("PUT_")) return;
        if (chatId == null || chatId.isBlank() || chatId.startsWith("PUT_")) return;

        String url = "https://api.telegram.org/bot" + token + "/sendMessage";
        String body = "chat_id=" + urlEncode(chatId) + "&text=" + urlEncode(text) + "&parse_mode=HTML";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(5))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                .build();

        http.sendAsync(request, HttpResponse.BodyHandlers.discarding())
                .exceptionally(ex -> {
                    plugin.getLogger().fine("[NangProtector] Telegram alert failed (server keeps running): " + ex.getMessage());
                    return null;
                });
    }

    private synchronized boolean allowedByRateLimit() {
        long now = System.currentTimeMillis();
        long last = lastSentMillis.get();
        int cooldownMs = config.telegramCooldownSeconds() * 1000;
        if (now - last < cooldownMs) return false;

        Instant cutoff = Instant.now().minusSeconds(60);
        sentTimestamps.removeIf(ts -> ts.isBefore(cutoff));
        if (sentTimestamps.size() >= config.telegramMaxPerMinute()) return false;

        sentTimestamps.add(Instant.now());
        lastSentMillis.set(now);
        return true;
    }

    private String formatMessage(SecurityEvent e) {
        StringBuilder sb = new StringBuilder();
        sb.append("\uD83D\uDEE1 <b>NangProtector Security Alert</b>\n\n");
        sb.append("Severity: ").append(emoji(e.getSeverity())).append(' ').append(e.getSeverity()).append('\n');
        sb.append("Event: ").append(escape(e.getType())).append('\n');
        if (e.getPlayer() != null) sb.append("Player: ").append(escape(e.getPlayer())).append('\n');
        if (e.getUuid() != null) sb.append("UUID: ").append(e.getUuid()).append('\n');
        sb.append("Action: ").append(escape(e.getAction())).append('\n');
        sb.append("Threat Score: ").append(e.getThreatScore()).append('\n');
        return sb.toString();
    }

    private String emoji(Severity s) {
        return switch (s) {
            case CRITICAL -> "\uD83D\uDD34";
            case HIGH -> "\uD83D\uDFE0";
            case LOW -> "\uD83D\uDFE1";
        };
    }

    private String escape(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private String urlEncode(String s) {
        return java.net.URLEncoder.encode(s, StandardCharsets.UTF_8);
    }
}
