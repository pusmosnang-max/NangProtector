package com.nangdev.nangprotector.lockdown;

import com.nangdev.nangprotector.config.ConfigManager;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * A simple gate: while active, only operators / nangprotector.bypass holders
 * may join. Toggled via the console-only /nangprotector command, or
 * automatically when threat score crosses the configured threshold (if enabled).
 */
public final class LockdownManager implements Listener {

    private final ConfigManager config;
    private final AtomicBoolean active = new AtomicBoolean(false);

    public LockdownManager(ConfigManager config) {
        this.config = config;
    }

    public boolean isActive() { return active.get(); }

    public void enable() { active.set(true); }

    public void disable() { active.set(false); }

    @EventHandler(priority = EventPriority.LOW)
    public void onLogin(PlayerLoginEvent event) {
        if (!active.get()) return;
        if (event.getPlayer().isOp() || event.getPlayer().hasPermission("nangprotector.bypass")) return;
        String msg = ChatColor.translateAlternateColorCodes('&', config.lockdownKickMessage());
        event.disallow(PlayerLoginEvent.Result.KICK_OTHER, msg);
    }
}
