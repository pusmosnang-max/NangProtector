package com.nangdev.nangprotector.alert;

import com.nangdev.nangprotector.config.ConfigManager;
import com.nangdev.nangprotector.model.Severity;
import com.nangdev.nangprotector.model.SecurityEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Discord webhook alerts, notification-only. NangProtector never treats Discord
 * as an input channel: it only ever POSTs, never listens for or acts on replies.
 * This class cannot execute commands, OP/deOP players, toggle lockdown, or touch
 * LuckPerms - it has no reference to anything capable of that.
 */
public final class DiscordAlert {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();

    private final AtomicLong lastSentMillis = new AtomicLong(0);
    private final Deque<Instant> sentTimestamps = new ArrayDeque<>();

    public DiscordAlert(JavaPlugin plugin, ConfigManager config) {
        this.plugin = plugin;
        this.config = config;
    }

    public void send(SecurityEvent e) {
        if (!config.discordEnabled()) return;
        Severity min = Severity.fromString(config.discordMinLevel(), Severity.HIGH);
        if (!e.getSeverity().isAtLeast(min)) return;
        postEmbed(buildEmbedJson(e));
    }

    public void sendPlainSummary(String title, String description) {
        if (!config.discordEnabled()) return;
        String json = """
            {"embeds":[{"title":%s,"description":%s,"color":16750899}]}
            """.formatted(jsonString(title), jsonString(description));
        postEmbed(json);
    }

    private void postEmbed(String json) {
        if (!allowedByRateLimit()) return;
        String url = config.discordWebhookUrl();
        if (url == null || url.isBlank() || url.startsWith("PUT_")) return;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(5))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                .build();

        http.sendAsync(request, HttpResponse.BodyHandlers.discarding())
                .exceptionally(ex -> {
                    plugin.getLogger().fine("[NangProtector] Discord alert failed (server keeps running): " + ex.getMessage());
                    return null;
                });
    }

    private synchronized boolean allowedByRateLimit() {
        long now = System.currentTimeMillis();
        long last = lastSentMillis.get();
        int cooldownMs = config.discordCooldownSeconds() * 1000;
        if (now - last < cooldownMs) return false;

        Instant cutoff = Instant.now().minusSeconds(60);
        sentTimestamps.removeIf(ts -> ts.isBefore(cutoff));
        if (sentTimestamps.size() >= config.discordMaxPerMinute()) return false;

        sentTimestamps.add(Instant.now());
        lastSentMillis.set(now);
        return true;
    }

    private String buildEmbedJson(SecurityEvent e) {
        int color = switch (e.getSeverity()) {
            case CRITICAL -> 0xE02B2B;
            case HIGH -> 0xE0A62B;
            case LOW -> 0xE0D02B;
        };
        String sevEmoji = switch (e.getSeverity()) {
            case CRITICAL -> "\uD83D\uDD34";
            case HIGH -> "\uD83D\uDFE0";
            case LOW -> "\uD83D\uDFE1";
        };

        StringBuilder desc = new StringBuilder();
        desc.append("**Severity:** ").append(sevEmoji).append(' ').append(e.getSeverity()).append('\n');
        desc.append("**Event:** ").append(e.getType()).append("\n\n");
        if (e.getPlayer() != null) desc.append("**Player:** ").append(e.getPlayer()).append('\n');
        if (e.getUuid() != null) desc.append("**UUID:** ").append(e.getUuid()).append('\n');
        desc.append("**Action:**\n").append(e.getAction()).append("\n\n");
        desc.append("**Threat Score:**\n").append(e.getThreatScore()).append("\n\n");
        desc.append("**Protection:**\n\uD83D\uDFE2 ACTIVE\n\n");
        desc.append("**Server:**\n").append(config.discordServerName()).append("\n\n");
        desc.append("**Time:**\n").append(TS.format(e.getTimestamp().atZone(java.time.ZoneId.systemDefault())));

        return """
            {"embeds":[{"title":"\uD83D\uDEE1\uFE0F NangProtector Security Alert","description":%s,"color":%d}]}
            """.formatted(jsonString(desc.toString()), color);
    }

    private String jsonString(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
                }
            }
        }
        sb.append('"');
        return sb.toString();
    }
}
