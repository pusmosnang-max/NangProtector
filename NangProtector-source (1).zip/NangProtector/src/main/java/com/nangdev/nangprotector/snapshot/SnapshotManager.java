package com.nangdev.nangprotector.snapshot;

import com.nangdev.nangprotector.config.ConfigManager;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.node.Node;
import net.luckperms.api.node.NodeType;
import net.luckperms.api.node.types.InheritanceNode;
import net.luckperms.api.node.types.PermissionNode;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Supplier;
import java.util.logging.Logger;

/**
 * Takes a small, cheap, periodic snapshot of just the security-relevant parts of
 * LuckPerms (protected groups' own permission nodes + parent groups) - never the
 * whole database, and never every second. Snapshots are the basis for *safe*,
 * additive recovery: NangProtector will re-add nodes a validated snapshot says
 * should exist, but will never delete/overwrite anything currently present and
 * will never touch LuckPerms's storage files directly.
 */
public final class SnapshotManager {

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final Supplier<LuckPerms> luckPermsSupplier;
    private final Logger logger;
    private final Path snapshotDir;

    private BukkitTask scheduledTask;

    public SnapshotManager(JavaPlugin plugin, ConfigManager config, Supplier<LuckPerms> luckPermsSupplier) {
        this.plugin = plugin;
        this.config = config;
        this.luckPermsSupplier = luckPermsSupplier;
        this.logger = plugin.getLogger();
        this.snapshotDir = plugin.getDataFolder().toPath().resolve("snapshots");
        try {
            Files.createDirectories(snapshotDir);
        } catch (IOException e) {
            logger.warning("[NangProtector] Could not create snapshot directory: " + e.getMessage());
        }
    }

    public void start() {
        if (!config.snapshotsEnabled()) return;
        long ticks = 20L * 60L * Math.max(1, config.snapshotIntervalMinutes());
        scheduledTask = plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, this::takeSnapshot, 20L * 30, ticks);
    }

    public void stop() {
        if (scheduledTask != null) scheduledTask.cancel();
    }

    public void takeSnapshot() {
        if (!config.snapshotsEnabled()) return;
        LuckPerms lp = luckPermsSupplier.get();
        if (lp == null) return;

        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("taken-at", Instant.now().toString());

        for (String groupName : config.protectedGroups()) {
            Group group = lp.getGroupManager().getGroup(groupName.toLowerCase());
            if (group == null) continue;

            List<String> permissions = new ArrayList<>();
            List<String> parents = new ArrayList<>();
            for (Node node : group.getNodes()) {
                if (node instanceof PermissionNode pn) {
                    permissions.add(pn.getPermission());
                } else if (node instanceof InheritanceNode in) {
                    parents.add(in.getGroupName());
                }
            }
            yaml.set("groups." + groupName + ".permissions", permissions);
            yaml.set("groups." + groupName + ".parents", parents);
        }

        String filename = "snapshot-" + Instant.now().toEpochMilli() + ".yml";
        Path target = snapshotDir.resolve(filename);
        try {
            yaml.save(target.toFile());
            pruneOldSnapshots();
        } catch (IOException e) {
            logger.warning("[NangProtector] Failed to write LuckPerms snapshot: " + e.getMessage());
        }
    }

    private void pruneOldSnapshots() {
        File[] files = snapshotDir.toFile().listFiles((dir, name) -> name.startsWith("snapshot-") && name.endsWith(".yml"));
        if (files == null || files.length <= config.maxSnapshots()) return;
        List<File> sorted = new ArrayList<>(List.of(files));
        sorted.sort(Comparator.comparingLong(File::lastModified));
        int toRemove = sorted.size() - config.maxSnapshots();
        for (int i = 0; i < toRemove; i++) {
            sorted.get(i).delete();
        }
    }

    /**
     * A protection module observed a change it could not (or should not) block
     * synchronously. Rather than doing anything drastic itself, it hands off a
     * plain-language hint here. If a validated snapshot exists, an additive
     * recovery attempt is queued; corrupt/unreadable snapshots are never used.
     */
    public void queueSafeRecoveryHint(String reason) {
        logger.warning("[NangProtector] " + reason);
        if (!config.snapshotsEnabled()) return;
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> restoreLatestValidSnapshot(reason));
    }

    public boolean restoreLatestValidSnapshot(String reason) {
        LuckPerms lp = luckPermsSupplier.get();
        if (lp == null) return false;

        File[] files = snapshotDir.toFile().listFiles((dir, name) -> name.startsWith("snapshot-") && name.endsWith(".yml"));
        if (files == null || files.length == 0) {
            logger.warning("[NangProtector] Safe-recovery requested but no snapshot exists yet. Skipping.");
            return false;
        }
        File latest = List.of(files).stream().max(Comparator.comparingLong(File::lastModified)).orElse(null);
        if (latest == null) return false;

        YamlConfiguration yaml = new YamlConfiguration();
        try {
            yaml.load(latest);
        } catch (Exception e) {
            logger.severe("[NangProtector] Snapshot '" + latest.getName() + "' is CORRUPT and will NOT be used for recovery: " + e.getMessage());
            return false;
        }

        if (!yaml.isConfigurationSection("groups") || yaml.getConfigurationSection("groups").getKeys(false).isEmpty()) {
            logger.warning("[NangProtector] Snapshot '" + latest.getName() + "' failed validation (empty/missing 'groups' section). Skipping restore.");
            return false;
        }

        int restoredNodes = 0;
        for (String groupName : yaml.getConfigurationSection("groups").getKeys(false)) {
            try {
                Group group = lp.getGroupManager().getGroup(groupName.toLowerCase());
                if (group == null) continue; // never re-create a deleted protected group blindly without an operator's decision

                List<String> permissions = yaml.getStringList("groups." + groupName + ".permissions");
                for (String perm : permissions) {
                    boolean present = group.getNodes(NodeType.PERMISSION).stream()
                            .anyMatch(n -> n.getPermission().equalsIgnoreCase(perm));
                    if (!present) {
                        group.data().add(PermissionNode.builder(perm).build());
                        restoredNodes++;
                    }
                }
                List<String> parents = yaml.getStringList("groups." + groupName + ".parents");
                for (String parent : parents) {
                    boolean present = group.getNodes(NodeType.INHERITANCE).stream()
                            .anyMatch(n -> n.getGroupName().equalsIgnoreCase(parent));
                    if (!present) {
                        group.data().add(InheritanceNode.builder(parent).build());
                        restoredNodes++;
                    }
                }
                lp.getGroupManager().saveGroup(group).join();
            } catch (Exception perGroupFailure) {
                logger.warning("[NangProtector] Restore failed for group '" + groupName + "': " + perGroupFailure.getMessage());
            }
        }

        logger.info("[NangProtector] Safe recovery from '" + latest.getName() + "' complete. Re-added " + restoredNodes
                + " missing node(s). Reason: " + reason);
        return true;
    }
}
