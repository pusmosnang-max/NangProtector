package com.nangdev.nangprotector.logging;

import com.nangdev.nangprotector.config.ConfigManager;
import com.nangdev.nangprotector.model.SecurityEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Never blocks the main thread: events are pushed onto a queue and drained by a
 * single dedicated background thread which appends to disk and rotates the file
 * when it grows too large. If the disk write fails, the exception is swallowed
 * (and reported once to console) rather than propagated - logging must never be
 * able to crash or freeze the server.
 */
public final class SecurityLogger {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final Path logPath;
    private final Path logDir;
    private final BlockingQueue<String> queue = new LinkedBlockingQueue<>();
    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "NangProtector-SecurityLogger");
        t.setDaemon(true);
        return t;
    });
    private final AtomicBoolean running = new AtomicBoolean(true);
    private final AtomicBoolean warnedOnce = new AtomicBoolean(false);

    public SecurityLogger(JavaPlugin plugin, ConfigManager config) {
        this.plugin = plugin;
        this.config = config;
        this.logDir = plugin.getDataFolder().toPath().resolve("logs");
        this.logPath = plugin.getDataFolder().toPath().resolve(config.logFile());
        try {
            Files.createDirectories(logPath.getParent());
        } catch (IOException e) {
            plugin.getLogger().warning("[NangProtector] Could not create log directory: " + e.getMessage());
        }
        worker.submit(this::drainLoop);
    }

    public void log(SecurityEvent e) {
        StringBuilder sb = new StringBuilder();
        sb.append('[').append(TS.format(e.getTimestamp().atZone(java.time.ZoneId.systemDefault()))).append("] ");
        sb.append('[').append(e.getSeverity()).append("] ");
        sb.append('[').append(e.getType()).append("]\n");
        if (e.getPlayer() != null) sb.append("Player=").append(e.getPlayer()).append(' ');
        if (e.getUuid() != null) sb.append("UUID=").append(e.getUuid()).append(' ');
        if (config.logIncludeIp() && e.getIp() != null) sb.append("IP=").append(e.getIp()).append(' ');
        if (e.getWorld() != null) sb.append("World=").append(e.getWorld()).append(' ');
        sb.append("Action=").append(e.getAction()).append(' ');
        sb.append("ThreatScore=").append(e.getThreatScore()).append(' ');
        sb.append("Source=").append(e.getDetectionSource());
        sb.append('\n');
        queue.offer(sb.toString());
    }

    private void drainLoop() {
        while (running.get() || !queue.isEmpty()) {
            try {
                String line = queue.poll(500, TimeUnit.MILLISECONDS);
                if (line == null) continue;
                rotateIfNeeded();
                try (Writer w = Files.newBufferedWriter(logPath, StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
                    w.write(line);
                }
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
            } catch (IOException ioe) {
                if (warnedOnce.compareAndSet(false, true)) {
                    plugin.getLogger().warning("[NangProtector] Security log write failed (further failures suppressed): " + ioe.getMessage());
                }
            }
        }
    }

    private void rotateIfNeeded() {
        try {
            if (!Files.exists(logPath)) return;
            long sizeMb = Files.size(logPath) / (1024L * 1024L);
            if (sizeMb < config.logMaxSizeMb()) return;
            String date = LocalDate.now().toString();
            Path rotated = logDir.resolve("security-" + date + ".log");
            int suffix = 1;
            Path candidate = rotated;
            while (Files.exists(candidate)) {
                candidate = logDir.resolve("security-" + date + "-" + (suffix++) + ".log");
            }
            Files.move(logPath, candidate);
        } catch (IOException e) {
            // best-effort; never throw from the logger
        }
    }

    public void shutdown() {
        running.set(false);
        worker.shutdown();
        try {
            worker.awaitTermination(3, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }
}
