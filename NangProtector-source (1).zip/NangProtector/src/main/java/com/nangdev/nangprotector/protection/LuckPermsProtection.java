package com.nangdev.nangprotector.protection;

import com.nangdev.nangprotector.alert.AlertManager;
import com.nangdev.nangprotector.config.ConfigManager;
import com.nangdev.nangprotector.model.Severity;
import com.nangdev.nangprotector.model.SecurityEvent;
import com.nangdev.nangprotector.snapshot.SnapshotManager;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.event.EventBus;
import net.luckperms.api.event.EventSubscription;
import net.luckperms.api.event.group.GroupDeleteEvent;
import net.luckperms.api.event.node.NodeAddEvent;
import net.luckperms.api.event.node.NodeClearEvent;
import net.luckperms.api.event.node.NodeRemoveEvent;
import net.luckperms.api.event.type.Cancellable;
import net.luckperms.api.model.PermissionHolder;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.Node;
import net.luckperms.api.node.types.InheritanceNode;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Integrates with LuckPerms (when present) to protect ranks/permissions from
 * destruction or unauthorized escalation.
 *
 * Design notes:
 *  - This is entirely soft-dependent: if LuckPerms is not installed, this class
 *    is simply never constructed (see NangProtector#onEnable).
 *  - Where the fired LuckPerms event implements {@link Cancellable} we attempt
 *    to cancel it outright, blocking the change synchronously. Where it does not
 *    (some mutation events are notify-only, depending on LuckPerms version and
 *    change source), we detect, log, alert, bump the threat score, and - if
 *    snapshots are enabled - queue a safe, validated snapshot restore rather
 *    than ever touching LuckPerms storage directly.
 *  - DDoSGuard/NangProtector NEVER writes to LuckPerms's own database files.
 *    Any "recovery" goes back through the LuckPerms API itself.
 */
public final class LuckPermsProtection {

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final AlertManager alerts;
    private final SnapshotManager snapshots;

    private LuckPerms luckPerms;
    private final List<EventSubscription<?>> subscriptions = new CopyOnWriteArrayList<>();

    // mass-change detection window
    private final Deque<Long> recentChangeTimestamps = new ArrayDeque<>();

    public LuckPermsProtection(JavaPlugin plugin, ConfigManager config, AlertManager alerts, SnapshotManager snapshots) {
        this.plugin = plugin;
        this.config = config;
        this.alerts = alerts;
        this.snapshots = snapshots;
    }

    public boolean hook() {
        if (!config.luckPermsProtectionEnabled()) return false;
        try {
            this.luckPerms = LuckPermsProvider.get();
        } catch (IllegalStateException notLoaded) {
            return false;
        }

        EventBus bus = luckPerms.getEventBus();
        subscriptions.add(bus.subscribe(plugin, GroupDeleteEvent.class, this::onGroupDelete));
        subscriptions.add(bus.subscribe(plugin, NodeAddEvent.class, this::onNodeAdd));
        subscriptions.add(bus.subscribe(plugin, NodeRemoveEvent.class, this::onNodeRemove));
        subscriptions.add(bus.subscribe(plugin, NodeClearEvent.class, this::onNodeClear));
        return true;
    }

    public void unhook() {
        for (EventSubscription<?> sub : subscriptions) sub.close();
        subscriptions.clear();
    }

    // ---------------------------------------------------------------
    // Group deletion
    // ---------------------------------------------------------------
    private void onGroupDelete(GroupDeleteEvent event) {
        String groupName = event.getGroupName();
        boolean protectedGroup = isProtectedGroup(groupName);

        recordChangeAndCheckMassDeletion("group deletion: " + groupName);

        if (!protectedGroup) return;

        boolean blocked = tryCancel(event);
        alerts.raise(SecurityEvent.builder("LUCKPERMS", Severity.CRITICAL)
                .action("LuckPerms group deletion detected. Group=" + groupName
                        + " Action=" + (blocked ? "BLOCKED" : "DETECTED"))
                .threatScore(80)
                .source("LuckPermsProtection")
                .build());

        if (!blocked && config.snapshotsEnabled()) {
            snapshots.queueSafeRecoveryHint("Protected group '" + groupName + "' was deleted and could not be blocked in-flight. "
                    + "Review the most recent verified snapshot and restore manually/automatically if configured.");
        }
    }

    // ---------------------------------------------------------------
    // Node (permission/parent) addition - covers wildcard grants and
    // promotions into protected groups.
    // ---------------------------------------------------------------
    private void onNodeAdd(NodeAddEvent event) {
        PermissionHolder target = event.getTarget();
        Node node = event.getNode();

        recordChangeAndCheckMassDeletion("node add on " + describeTarget(target) + ": " + node.getKey());

        // Case 1: a protected/dangerous permission string was granted
        if (isProtectedPermission(node.getKey())) {
            boolean blocked = tryCancel(event);
            alerts.raise(SecurityEvent.builder("LUCKPERMS", Severity.CRITICAL)
                    .action("Dangerous permission granted: '" + node.getKey() + "' on " + describeTarget(target)
                            + " Action=" + (blocked ? "BLOCKED" : "DETECTED"))
                    .threatScore(70)
                    .source("LuckPermsProtection")
                    .build());
            return;
        }

        // Case 2: a user was granted parent-group inheritance of a protected group (i.e. "promoted")
        if (node instanceof InheritanceNode inheritance && target instanceof User user) {
            String parentGroup = inheritance.getGroupName();
            if (isProtectedGroup(parentGroup)) {
                boolean blocked = tryCancel(event);
                alerts.raise(SecurityEvent.builder("LUCKPERMS", Severity.CRITICAL)
                        .player(user.getUsername() != null ? user.getUsername() : user.getUniqueId().toString())
                        .uuid(user.getUniqueId())
                        .action("User promoted into protected group '" + parentGroup + "'"
                                + " Action=" + (blocked ? "BLOCKED" : "DETECTED"))
                        .threatScore(70)
                        .source("LuckPermsProtection")
                        .build());
            }
        }
    }

    // ---------------------------------------------------------------
    // Node removal - covers stripping permissions from protected groups.
    // ---------------------------------------------------------------
    private void onNodeRemove(NodeRemoveEvent event) {
        PermissionHolder target = event.getTarget();
        Node node = event.getNode();

        recordChangeAndCheckMassDeletion("node remove on " + describeTarget(target) + ": " + node.getKey());

        if (target instanceof Group group && isProtectedGroup(group.getName())) {
            boolean blocked = tryCancel(event);
            alerts.raise(SecurityEvent.builder("LUCKPERMS", Severity.HIGH)
                    .action("Permission removed from protected group '" + group.getName() + "': '" + node.getKey() + "'"
                            + " Action=" + (blocked ? "BLOCKED" : "DETECTED"))
                    .threatScore(40)
                    .source("LuckPermsProtection")
                    .build());
        }
    }

    // ---------------------------------------------------------------
    // Node clear - a full permission wipe on a holder ("unexpected permission reset").
    // ---------------------------------------------------------------
    private void onNodeClear(NodeClearEvent event) {
        PermissionHolder target = event.getTarget();
        recordChangeAndCheckMassDeletion("node clear on " + describeTarget(target));

        boolean protectedTarget = (target instanceof Group group && isProtectedGroup(group.getName()));
        boolean blocked = protectedTarget && tryCancel(event);

        alerts.raise(SecurityEvent.builder("LUCKPERMS", protectedTarget ? Severity.CRITICAL : Severity.HIGH)
                .action("Unexpected permission reset on " + describeTarget(target)
                        + (protectedTarget ? " Action=" + (blocked ? "BLOCKED" : "DETECTED") : ""))
                .threatScore(protectedTarget ? 70 : 25)
                .source("LuckPermsProtection")
                .build());

        if (protectedTarget && !blocked && config.snapshotsEnabled()) {
            snapshots.queueSafeRecoveryHint("Protected holder '" + describeTarget(target) + "' had its permissions cleared. "
                    + "Review the most recent verified snapshot.");
        }
    }

    // ---------------------------------------------------------------
    // Mass-change detection (shared sliding window across all mutation types)
    // ---------------------------------------------------------------
    private synchronized void recordChangeAndCheckMassDeletion(String description) {
        if (!config.massChangeEnabled()) return;
        long now = System.currentTimeMillis();
        long windowMs = config.massChangeWindowSeconds() * 1000L;
        recentChangeTimestamps.addLast(now);
        while (!recentChangeTimestamps.isEmpty() && now - recentChangeTimestamps.peekFirst() > windowMs) {
            recentChangeTimestamps.pollFirst();
        }
        if (recentChangeTimestamps.size() >= config.massChangeThreshold()) {
            alerts.raise(SecurityEvent.builder("LUCKPERMS", Severity.CRITICAL)
                    .action("Mass LuckPerms change detected: " + recentChangeTimestamps.size()
                            + " changes within " + config.massChangeWindowSeconds() + "s (possible permission destruction). Last: " + description)
                    .threatScore(100)
                    .source("LuckPermsProtection")
                    .build());
            recentChangeTimestamps.clear();
        }
    }

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------
    private boolean tryCancel(Object event) {
        if (event instanceof Cancellable cancellable) {
            cancellable.setCancelled(true);
            return true;
        }
        return false;
    }

    private boolean isProtectedGroup(String name) {
        if (name == null) return false;
        for (String g : config.protectedGroups()) {
            if (g.equalsIgnoreCase(name)) return true;
        }
        return false;
    }

    private boolean isProtectedPermission(String key) {
        if (key == null) return false;
        String lower = key.toLowerCase(Locale.ROOT);
        for (String p : config.protectedPermissions()) {
            String pl = p.toLowerCase(Locale.ROOT);
            if (pl.equals(lower)) return true;
            if (pl.endsWith("*") && lower.startsWith(pl.substring(0, pl.length() - 1))) return true;
        }
        return false;
    }

    private String describeTarget(PermissionHolder holder) {
        if (holder instanceof Group g) return "group:" + g.getName();
        if (holder instanceof User u) return "user:" + (u.getUsername() != null ? u.getUsername() : u.getUniqueId().toString());
        return holder.getIdentifier().toString();
    }
}
